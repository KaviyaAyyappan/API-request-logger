<?php
/**
 * Plugin Name: API Request Logger
 * Description: Logs all WordPress REST API requests (method, route, user, IP, params, status) including CPU time, peak memory, and duration. Adds an admin page under Tools → API Logs.
 * Version: 1.2.0
 * Author: Kaviya Ayyappan
 * Requires at least: 5.8
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'API_REQ_LOGGER_VERSION', '1.2.0' );
define( 'API_REQ_LOGGER_PLUGIN_FILE', __FILE__ );

global $api_req_logger_db_version;
$api_req_logger_db_version = '1.2.0';

/**
 * Activation: create table & options.
 */
function api_req_logger_activate() {
	global $wpdb, $api_req_logger_db_version;

	$table = $wpdb->prefix . 'api_log';
	$charset_collate = $wpdb->get_charset_collate();

	// Use dbDelta-compatible schema. Keep indexes short for utf8mb4.
	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		time DATETIME NOT NULL,
		ip VARCHAR(100) NOT NULL DEFAULT '',
		method VARCHAR(10) NOT NULL DEFAULT '',
		route VARCHAR(255) NOT NULL DEFAULT '',
		user BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		status SMALLINT(5) UNSIGNED NOT NULL DEFAULT 0,
		duration_ms INT(10) UNSIGNED NOT NULL DEFAULT 0,
		cpu_time FLOAT NOT NULL DEFAULT 0,
		memory BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		user_agent VARCHAR(255) NOT NULL DEFAULT '',
		referer VARCHAR(255) NOT NULL DEFAULT '',
		params LONGTEXT NULL,
		PRIMARY KEY  (id),
		KEY time_idx (time),
		KEY method_idx (method),
		KEY status_idx (status),
		KEY route_idx (route(191))
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	add_option( 'api_req_logger_db_version', $api_req_logger_db_version );
	// Default retention: 30 days (0 = keep forever)
	if ( get_option( 'api_req_logger_retention_days', null ) === null ) {
		add_option( 'api_req_logger_retention_days', 30 );
	}

	// Schedule daily pruning if not already scheduled
	if ( ! wp_next_scheduled( 'api_req_logger_daily_prune' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'api_req_logger_daily_prune' );
	}
}
register_activation_hook( __FILE__, 'api_req_logger_activate' );

/**
 * Deactivation: unschedule cron (keeps data).
 */
function api_req_logger_deactivate() {
	wp_clear_scheduled_hook( 'api_req_logger_daily_prune' );
}
register_deactivation_hook( __FILE__, 'api_req_logger_deactivate' );

/**
 * Uninstall helper (optional): set this option to 1 then delete plugin to drop table.
 * We don't drop data by default for safety.
 */
register_uninstall_hook( __FILE__, 'api_req_logger_uninstall' );
function api_req_logger_uninstall() {
	if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) return;
	$drop = (int) get_option( 'api_req_logger_drop_on_uninstall', 0 );
	if ( $drop ) {
		global $wpdb;
		$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}api_log" );
		delete_option( 'api_req_logger_db_version' );
		delete_option( 'api_req_logger_retention_days' );
		delete_option( 'api_req_logger_drop_on_uninstall' );
	}
}

/**
 * CRON: prune old rows based on retention setting.
 */
add_action( 'api_req_logger_daily_prune', function() {
	$days = (int) get_option( 'api_req_logger_retention_days', 30 );
	if ( $days > 0 ) {
		global $wpdb;
		$table = $wpdb->prefix . 'api_log';
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM $table WHERE time < (NOW() - INTERVAL %d DAY)",
			$days
		) );
	}
} );

/**
 * Internal per-request context store.
 */
class API_Req_Logger_Ctx {
	public static float $start_ts = 0.0;
	public static ?array $rusage_start = null;
	public static int $status = 0;

	public static function reset() {
		self::$start_ts     = microtime(true);
		self::$rusage_start = function_exists('getrusage') ? getrusage() : null;
		self::$status       = 0;
	}
}
API_Req_Logger_Ctx::reset();

/**
 * Hook early: start timing and capture start CPU usage on REST requests.
 */
add_action( 'rest_api_init', function() {
	// Start timing when server is about to dispatch.
	add_action( 'rest_pre_dispatch', function( $result, $server, $request ) {
		API_Req_Logger_Ctx::reset();
		return $result;
	}, 1, 3 );

	// After callbacks produce a response, capture status and log.
	add_filter( 'rest_request_after_callbacks', function( $response, $handler, $request ) {
		// Compute CPU time (best-effort on Linux)
		$cpu_time = 0;
		if ( function_exists('getrusage') && API_Req_Logger_Ctx::$rusage_start ) {
			$end = getrusage();
			$start = API_Req_Logger_Ctx::$rusage_start;
			$cpu_time =
				(($end['ru_utime.tv_sec']  ?? 0) - ($start['ru_utime.tv_sec']  ?? 0)) +
				(($end['ru_utime.tv_usec'] ?? 0) - ($start['ru_utime.tv_usec'] ?? 0)) / 1e6 +
				(($end['ru_stime.tv_sec']  ?? 0) - ($start['ru_stime.tv_sec']  ?? 0)) +
				(($end['ru_stime.tv_usec'] ?? 0) - ($start['ru_stime.tv_usec'] ?? 0)) / 1e6;
		}

		$duration_ms = (int) round( (microtime(true) - API_Req_Logger_Ctx::$start_ts) * 1000 );

		$status_code = 0;
		if ( is_wp_error( $response ) ) {
			$status_code = $response->get_error_code() ? 500 : 500;
		} elseif ( $response instanceof WP_HTTP_Response ) {
			$status_code = (int) $response->get_status();
		}

		// Build row
		$log_entry = array(
			'time'        => current_time( 'mysql' ),
			'ip'          => $_SERVER['REMOTE_ADDR']   ?? '',
			'method'      => $request->get_method(),
			'route'       => $request->get_route(),
			'user'        => get_current_user_id(),
			'status'      => $status_code,
			'duration_ms' => $duration_ms,
			'cpu_time'    => $cpu_time,
			'memory'      => function_exists('memory_get_peak_usage') ? memory_get_peak_usage(true) : 0,
			'user_agent'  => substr( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 255 ),
			'referer'     => substr( (string) ( $_SERVER['HTTP_REFERER']     ?? '' ), 0, 255 ),
			'params'      => null, // set below
		);

		// Capture params safely as JSON (truncate very large bodies)
		$params = $request->get_params();
		$json   = wp_json_encode( $params, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( $json === false ) {
			$json = '{"_error":"json_encode_failed"}';
		}
		$max_len = 20000; // limit to 20KB to avoid massive rows
		if ( strlen( $json ) > $max_len ) {
			$json = substr( $json, 0, $max_len ) . '... [truncated]';
		}
		$log_entry['params'] = $json;

		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'api_log', $log_entry );

		return $response;
	}, 999, 3 );
} );

/**
 * Admin page: Tools → API Logs
 */
add_action( 'admin_menu', function() {
	add_management_page(
		'API Logs',
		'API Logs',
		'manage_options',
		'api-req-logs',
		'api_req_logger_admin_page'
	);
} );

/**
 * Render admin page.
 */
function api_req_logger_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have sufficient permissions to access this page.' ) );
	}

	global $wpdb;
	$table = $wpdb->prefix . 'api_log';

	// Handle actions: clear logs, save settings
	if ( isset( $_POST['api_req_logger_action'] ) && check_admin_referer( 'api_req_logger_action', 'api_req_logger_nonce' ) ) {
		$action = sanitize_text_field( wp_unslash( $_POST['api_req_logger_action'] ) );
		if ( $action === 'clear' ) {
			$wpdb->query( "TRUNCATE TABLE $table" );
			echo '<div class="updated"><p>Logs cleared.</p></div>';
		} elseif ( $action === 'save_settings' ) {
			$retention = isset($_POST['retention_days']) ? (int) $_POST['retention_days'] : 0;
			update_option( 'api_req_logger_retention_days', max(0, $retention) );
			$drop = ! empty( $_POST['drop_on_uninstall'] ) ? 1 : 0;
			update_option( 'api_req_logger_drop_on_uninstall', $drop );
			echo '<div class="updated"><p>Settings saved.</p></div>';
		}
	}

	// Filters / search
	$per_page   = 50;
	$paged      = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
	$offset     = ( $paged - 1 ) * $per_page;

	$method     = isset($_GET['method']) ? strtoupper( sanitize_text_field( wp_unslash($_GET['method']) ) ) : '';
	$status     = isset($_GET['status']) ? (int) $_GET['status'] : 0;
	$search     = isset($_GET['s'])      ? trim( sanitize_text_field( wp_unslash($_GET['s']) ) ) : '';
	$user_id    = isset($_GET['user'])   ? max(0, (int) $_GET['user']) : 0;

	$where = [];
	$args  = [];

	if ( $method ) { $where[] = 'method = %s'; $args[] = $method; }
	if ( $status ) { $where[] = 'status = %d'; $args[] = $status; }
	if ( $user_id ){ $where[] = 'user = %d';   $args[] = $user_id; }
	if ( $search ) {
		$where[] = '(route LIKE %s OR ip LIKE %s OR user_agent LIKE %s)';
		$like = '%' . $wpdb->esc_like( $search ) . '%';
		$args[] = $like; $args[] = $like; $args[] = $like;
	}

	$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';

	$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table $where_sql", $args ) );
	$rows  = $wpdb->get_results( $wpdb->prepare(
		"SELECT * FROM $table $where_sql ORDER BY id DESC LIMIT %d OFFSET %d",
		array_merge( $args, [ $per_page, $offset ] )
	), ARRAY_A );

	$base_url = admin_url( 'tools.php?page=api-req-logs' );
	$query_base = $base_url;
	$q = [];
	if ( $method ) $q['method'] = $method;
	if ( $status ) $q['status'] = $status;
	if ( $user_id ) $q['user']  = $user_id;
	if ( $search ) $q['s'] = $search;
	if ( $q ) $query_base = add_query_arg( $q, $base_url );

	$total_pages = max( 1, (int) ceil( $total / $per_page ) );

	// Settings
	$retention_days = (int) get_option( 'api_req_logger_retention_days', 30 );
	$drop_on_uninstall = (int) get_option( 'api_req_logger_drop_on_uninstall', 0 );

	?>
	<div class="wrap">
		<h1>API Logs</h1>

		<form method="get" style="margin-top:10px; margin-bottom:20px;">
			<input type="hidden" name="page" value="api-req-logs" />
			<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Search route, IP, user agent…" />
			<select name="method">
				<option value="">Method</option>
				<?php foreach ( ['GET','POST','PUT','PATCH','DELETE','OPTIONS'] as $m ): ?>
					<option value="<?php echo esc_attr($m); ?>" <?php selected( $method, $m ); ?>><?php echo esc_html($m); ?></option>
				<?php endforeach; ?>
			</select>
			<input type="number" name="status" value="<?php echo esc_attr( $status ?: '' ); ?>" placeholder="Status" min="0" step="1" style="width:100px;" />
			<input type="number" name="user" value="<?php echo esc_attr( $user_id ?: '' ); ?>" placeholder="User ID" min="0" step="1" style="width:100px;" />
			<button class="button">Filter</button>
			<a class="button" href="<?php echo esc_url( $base_url ); ?>">Reset</a>
		</form>

		<form method="post" style="margin-bottom:20px;">
			<?php wp_nonce_field( 'api_req_logger_action', 'api_req_logger_nonce' ); ?>
			<input type="hidden" name="api_req_logger_action" value="clear" />
			<button class="button button-secondary" onclick="return confirm('Clear ALL logs? This cannot be undone.');">Clear Logs</button>
		</form>

		<h2 class="title">Retention & Settings</h2>
		<form method="post" style="margin-bottom:20px;">
			<?php wp_nonce_field( 'api_req_logger_action', 'api_req_logger_nonce' ); ?>
			<input type="hidden" name="api_req_logger_action" value="save_settings" />
			<label>
				Retention (days):
				<input type="number" name="retention_days" min="0" step="1" value="<?php echo esc_attr( $retention_days ); ?>" />
			</label>
			<p class="description">0 = keep logs forever. A daily cron will prune older entries.</p>
			<label style="display:block; margin-top:8px;">
				<input type="checkbox" name="drop_on_uninstall" value="1" <?php checked( $drop_on_uninstall, 1 ); ?> />
				Drop table on plugin uninstall (delete data)
			</label>
			<button class="button button-primary" style="margin-top:8px;">Save Settings</button>
		</form>

		<h2 class="title">Logs (<?php echo number_format_i18n( $total ); ?>)</h2>

		<table class="widefat fixed striped">
			<thead>
				<tr>
					<th>ID</th>
					<th>Time</th>
					<th>IP</th>
					<th>Method</th>
					<th style="width:28%;">Route</th>
					<th>User</th>
					<th>Status</th>
					<th>Dur (ms)</th>
					<th>CPU (s)</th>
					<th>Mem (MB)</th>
					<th>User Agent</th>
					<th style="width:20%;">Params</th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ): ?>
					<tr><td colspan="12">No logs found.</td></tr>
				<?php else: ?>
					<?php foreach ( $rows as $r ):
						$mem_mb = $r['memory'] ? number_format_i18n( $r['memory'] / 1048576, 2 ) : '0.00';
						$params_display = '';
						if ( ! empty( $r['params'] ) ) {
							$params_display = esc_html( mb_strimwidth( $r['params'], 0, 500, '…' ) );
						}
					?>
						<tr>
							<td><?php echo (int) $r['id']; ?></td>
							<td><?php echo esc_html( $r['time'] ); ?></td>
							<td><?php echo esc_html( $r['ip'] ); ?></td>
							<td><?php echo esc_html( $r['method'] ); ?></td>
							<td><code style="white-space:nowrap;"><?php echo esc_html( $r['route'] ); ?></code></td>
							<td><?php echo (int) $r['user']; ?></td>
							<td><?php echo (int) $r['status']; ?></td>
							<td><?php echo (int) $r['duration_ms']; ?></td>
							<td><?php echo esc_html( number_format_i18n( (float) $r['cpu_time'], 3 ) ); ?></td>
							<td><?php echo esc_html( $mem_mb ); ?></td>
							<td title="<?php echo esc_attr( $r['user_agent'] ); ?>"><?php echo esc_html( mb_strimwidth( $r['user_agent'], 0, 30, '…' ) ); ?></td>
							<td><details><summary>view</summary><pre style="white-space:pre-wrap;margin:0;"><?php echo $params_display; ?></pre></details></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>

		<?php if ( $total_pages > 1 ): ?>
			<div class="tablenav">
				<div class="tablenav-pages">
					<span class="pagination-links">
						<?php
						$page_links = paginate_links( array(
							'base'      => add_query_arg( 'paged', '%#%', $query_base ),
							'format'    => '',
							'prev_text' => '«',
							'next_text' => '»',
							'total'     => $total_pages,
							'current'   => $paged,
						) );
						echo $page_links ? $page_links : '';
						?>
					</span>
				</div>
			</div>
		<?php endif; ?>

		<p style="margin-top:20px;color:#666;">
			<em>Tip:</em> You can filter by <strong>Method</strong>, <strong>Status</strong>, <strong>User ID</strong>, or search by <strong>Route/IP/User-Agent</strong>.
		</p>
	</div>
	<?php
}
